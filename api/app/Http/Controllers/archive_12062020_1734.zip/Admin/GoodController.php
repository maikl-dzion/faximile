<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class GoodController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Good $model)
    {
        //
    }

    public function edit(Good $model)
    {
        //
    }


    public function update(Request $request, Good $model)
    {
        //
    }

    public function destroy(Good $model)
    {
        //
    }
}
