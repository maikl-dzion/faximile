<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Category $model)
    {
        //
    }

    public function edit(Category $model)
    {
        //
    }


    public function update(Request $request, Category $model)
    {
        //
    }


    public function destroy(Category $model)
    {
        //
    }
}
